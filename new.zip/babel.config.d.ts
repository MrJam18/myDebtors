declare function _exports(api: any): {
    plugins: string[];
};
export = _exports;
