declare module '*.css';
declare module '*.svg';
declare module '*.png';