<?php
declare(strict_types=1);

namespace App\Http\Requests\Base;

use Illuminate\Foundation\Http\FormRequest;

abstract class BaseRequest extends FormRequest
{

}
