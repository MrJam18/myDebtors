declare const _exports: {
    'fontawesome-svg-core': {
        license: string;
    };
};
export = _exports;
