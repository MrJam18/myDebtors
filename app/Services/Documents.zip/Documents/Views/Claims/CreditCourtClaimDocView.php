<?php
declare(strict_types=1);

namespace App\Services\Documents\Views\Claims;

class CreditCourtClaimDocView extends CreditClaimDocView
{
    use CourtClaimTrait;

}