<?php
declare(strict_types=1);

namespace App\Services\Counters\Base;

use Illuminate\Support\Collection;

class Holidays
{
    private Collection $list;

    public function __construct()
    {
    }

}