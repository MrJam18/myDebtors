<?php
declare(strict_types=1);

namespace App\Services;

use App\Services\AbstractServices\BaseService;

class UserService extends BaseService
{
    function login(string $email, string $password)
    {
    }
}
